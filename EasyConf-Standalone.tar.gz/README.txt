EasyConf - Network Configuration Variable Replacement Tool
=========================================================

USAGE INSTRUCTIONS:
-------------------

This is a standalone web application that works completely offline.

HOW TO USE:
1. Simply open "index.html" in any modern web browser
   - Double-click index.html, OR
   - Right-click index.html → Open with → Your browser (Chrome, Firefox, Edge, Safari)

2. The application will open in your browser and work completely offline

3. All your data is saved in your browser's local storage
   - Data persists across browser restarts
   - Data is stored locally on your computer (no internet needed)

IMPORTANT NOTES:
- Keep all files in the same folder (especially the _next folder)
- Do NOT move or delete any files - they are all needed
- Works in: Chrome, Firefox, Edge, Safari (modern versions)
- No installation required
- No internet connection required (after first open)
- No server or npm needed

FEATURES:
---------
✓ Create multiple configuration tabs
✓ Use {{ variableName }} syntax for variables
✓ Auto-detect variables from your configuration
✓ Generate configurations with replaced variables
✓ Adjustable line spacing (1-20 lines)
✓ Copy to clipboard functionality
✓ Dark mode support
✓ All data saved automatically in browser

TROUBLESHOOTING:
----------------
If the page doesn't load properly:
1. Make sure all files (especially _next folder) are in the same directory
2. Try a different browser
3. Check browser console for errors (F12 → Console tab)

HOSTING ON A SERVER (OPTIONAL):
-------------------------------
If you want to host this on a web server:
1. Upload all files and folders to your web server
2. Access via http://yourserver.com/index.html
3. Works on any static file server (Apache, Nginx, etc.)
   No PHP, Node.js, or database required!

SYSTEM REQUIREMENTS:
-------------------
- Modern web browser (Chrome 90+, Firefox 88+, Edge 90+, Safari 14+)
- JavaScript enabled
- Local storage enabled
- ~1MB of disk space

---
Built with Next.js • Completely Static • No Backend Required
